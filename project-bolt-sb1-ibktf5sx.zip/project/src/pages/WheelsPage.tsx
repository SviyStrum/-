import { useState, useMemo } from 'react';
import { WHEEL_TYPES, WHEEL_DIAMETERS, WHEEL_BRANDS } from '../data/constants';
import ProductCard from '../components/ProductCard';
import ContactModal from '../components/ContactModal';
import InfoBanner from '../components/InfoBanner';

export default function WheelsPage() {
  const [contactCode, setContactCode] = useState<number | null>(null);

  const wheelModules = useMemo(() => {
    const modules = import.meta.glob('/public/wheel-cards/*.{png,jpg,jpeg,webp}', { eager: true });
    return Object.entries(modules).map(([path, mod], index) => {
      const url = (mod as { default: string }).default || path;
      const code = 512 + index;
      return { image: url, code };
    });
  }, []);

  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-white mb-2">Каталог дисків</h1>
        <p className="text-gray-400 text-sm mb-8">Преміальні диски для власників престижних автомобілів</p>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left Sidebar */}
          <aside className="lg:w-64 flex-shrink-0">
            <div className="lg:sticky lg:top-24 space-y-6">
              <div className="bg-neutral-900 border border-white/10 rounded-xl p-5">
                <h3 className="text-white font-semibold text-sm mb-3">Типи дисків</h3>
                <div className="flex flex-wrap gap-2">
                  {WHEEL_TYPES.map((type) => (
                    <span
                      key={type}
                      className="inline-flex w-fit px-3 py-1.5 bg-white/5 border border-white/10 rounded-md text-xs text-gray-300"
                    >
                      {type}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-neutral-900 border border-white/10 rounded-xl p-5">
                <h3 className="text-white font-semibold text-sm mb-3">Діаметри</h3>
                <div className="flex flex-wrap gap-2">
                  {WHEEL_DIAMETERS.map((d) => (
                    <span
                      key={d}
                      className="inline-flex w-fit px-3 py-1.5 bg-white/5 border border-white/10 rounded-md text-xs text-gray-300"
                    >
                      {d}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-neutral-900 border border-white/10 rounded-xl p-5">
                <h3 className="text-white font-semibold text-sm mb-3">Бренди</h3>
                <div className="flex flex-wrap gap-2">
                  {WHEEL_BRANDS.map((brand) => (
                    <span
                      key={brand}
                      className="inline-flex w-fit px-3 py-1.5 bg-white/5 border border-white/10 rounded-md text-xs text-gray-300"
                    >
                      {brand}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Product Grid */}
          <div className="flex-1 space-y-6">
            <InfoBanner />
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {wheelModules.map((item) => (
                <ProductCard
                  key={item.code}
                  image={item.image}
                  code={item.code}
                  onContact={setContactCode}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {contactCode !== null && (
        <ContactModal productCode={String(contactCode)} onClose={() => setContactCode(null)} />
      )}
    </div>
  );
}
