import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, Search, CircleDot, Shield, Truck, MessageCircle } from 'lucide-react';
import InfoBanner from '../components/InfoBanner';
import { CAR_BRANDS, TESTIMONIALS } from '../data/constants';
import ContactModal from '../components/ContactModal';

export default function HomePage() {
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [modification, setModification] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const handleCarSelection = () => {
    if (!brand.trim() || !model.trim() || !year.trim()) {
      alert('Будь ласка, заповніть обов\'язкові поля: Марка, Модель та Рік');
      return;
    }
    const message = `Добрий день! Потрібна допомога менеджера у підборі.\nАвто: ${brand}\nМодель: ${model}\nРік: ${year}\nМодифікація: ${modification || '—'}`;
    setModalMessage(message);
    setShowModal(true);
  };

  const nextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const prevTestimonial = () => {
    setTestimonialIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  const visibleTestimonials = () => {
    const items = [];
    for (let i = 0; i < 3; i++) {
      items.push(TESTIMONIALS[(testimonialIndex + i) % TESTIMONIALS.length]);
    }
    return items;
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section with Video Background */}
      <section className="relative overflow-hidden min-h-screen flex items-center">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover z-0"
        >
          <source src="/hero-bg.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-black/65 z-0" />

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 pt-28">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
                Преміальні диски<br />
                <span className="text-orange-500">та шини</span><br />
                для вашого авто
              </h1>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Підбір оригінальних дисків та шин преміум класу для власників престижних автомобілів.
                Консультація та доставка по всій Україні.
              </p>
              <div className="flex gap-4">
                <div className="flex items-center gap-2 text-gray-400 text-sm">
                  <Shield className="w-5 h-5 text-orange-500" />
                  <span>Оригінальні вироби</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400 text-sm">
                  <Truck className="w-5 h-5 text-orange-500" />
                  <span>Доставка по Україні</span>
                </div>
              </div>
            </div>

            {/* Car Selection Widget */}
            <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-2 mb-6">
                <Search className="w-5 h-5 text-orange-500" />
                <h2 className="text-white text-xl font-semibold">Підбір по автомобілю</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Марка автомобіля *</label>
                  <input
                    type="text"
                    list="car-brands"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    placeholder="Почніть друкувати або оберіть марку"
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors placeholder-gray-500"
                  />
                  <datalist id="car-brands">
                    {CAR_BRANDS.map((b) => (
                      <option key={b} value={b} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-gray-400 text-sm mb-2">Модель *</label>
                  <input
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="Наприклад: Cayenne, M5, RS6"
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors placeholder-gray-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Рік випуску *</label>
                    <input
                      type="text"
                      value={year}
                      onChange={(e) => setYear(e.target.value)}
                      placeholder="2022"
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors placeholder-gray-500"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Модифікація</label>
                    <input
                      type="text"
                      value={modification}
                      onChange={(e) => setModification(e.target.value)}
                      placeholder="3.0 Diesel"
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors placeholder-gray-500"
                    />
                  </div>
                </div>
                <button
                  onClick={handleCarSelection}
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 rounded-lg transition-colors"
                >
                  Підібрати
                </button>
              </div>
            </div>
          </div>
          <div className="mt-8 lg:mt-12">
            <InfoBanner />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-14 h-14 bg-orange-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <CircleDot className="w-7 h-7 text-orange-500" />
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">Оригінальні вироби</h3>
              <p className="text-gray-400 text-sm">Лише оригінальні диски та шини від світових виробників преміум сегменту</p>
            </div>
            <div className="text-center p-6">
              <div className="w-14 h-14 bg-orange-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Truck className="w-7 h-7 text-orange-500" />
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">Доставка Новою Поштою</h3>
              <p className="text-gray-400 text-sm">Швидка доставка по всій Україні з надійною упаковкою для захисту товару</p>
            </div>
            <div className="text-center p-6">
              <div className="w-14 h-14 bg-orange-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-7 h-7 text-orange-500" />
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">Оплата після огляду</h3>
              <p className="text-gray-400 text-sm">Перевірте товар при отриманні і сплачуйте лише після огляду</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-white text-3xl font-bold text-center mb-12">Відгуки наших клієнтів</h2>
          <div className="relative">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {visibleTestimonials().map((t, i) => (
                <div key={i} className="bg-neutral-900 border border-white/10 rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-orange-500/10 rounded-full flex items-center justify-center">
                      <span className="text-orange-500 font-bold text-sm">{t.name[0]}</span>
                    </div>
                    <div>
                      <p className="text-white font-medium text-sm">{t.name}</p>
                      <p className="text-gray-500 text-xs">{t.car}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 mb-3">
                    {Array.from({ length: 5 }).map((_, si) => (
                      <Star
                        key={si}
                        className={`w-4 h-4 ${si < t.rating ? 'text-orange-500 fill-orange-500' : 'text-gray-600'}`}
                      />
                    ))}
                  </div>
                  <p className="text-gray-400 text-sm leading-relaxed">{t.text}</p>
                </div>
              ))}
            </div>
            <div className="flex justify-center gap-3 mt-8">
              <button
                onClick={prevTestimonial}
                className="w-10 h-10 bg-white/5 hover:bg-white/10 rounded-full flex items-center justify-center text-white transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={nextTestimonial}
                className="w-10 h-10 bg-white/5 hover:bg-white/10 rounded-full flex items-center justify-center text-white transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {showModal && <ContactModal onClose={() => setShowModal(false)} customMessage={modalMessage} />}
    </div>
  );
}
