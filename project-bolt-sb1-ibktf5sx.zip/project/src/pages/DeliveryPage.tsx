import { Truck, Package, ShieldCheck, Clock, MapPin, CreditCard } from 'lucide-react';

export default function DeliveryPage() {
  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold text-white mb-2">Доставка</h1>
        <p className="text-gray-400 text-sm mb-10">Інформація про доставку та оплату по всій Україні</p>

        <div className="space-y-8">
          <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Truck className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg mb-2">Доставка Новою Поштою</h2>
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  Ми відправляємо замовлення по всій Україні через службу доставки «Нова Пошта». 
                  Терміни доставки зазвичай становлять 1-3 робочих дні залежно від вашого регіону. 
                  Після відправки ви отримаєте номер ТТН для відстеження посилки в реальному часі.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex items-center gap-2 text-gray-400 text-sm">
                    <Clock className="w-4 h-4 text-orange-500" />
                    <span>1-3 робочі дні по Україні</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-400 text-sm">
                    <MapPin className="w-4 h-4 text-orange-500" />
                    <span>Відділення або адресна доставка</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Package className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg mb-2">Надійна упаковка</h2>
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  Диски та шини пакуються в міцний картон та спеціальний захисний матеріал для запобігання 
                  пошкоджень під час транспортування. Кожен диск додатково захищено пінопластовими 
                  вставками. Ми цінуємо преміальність товару і ретельно стежимо за тим, щоб він 
                  прибув до вас у бездоганному стані.
                </p>
                <div className="flex items-center gap-2 text-gray-400 text-sm">
                  <ShieldCheck className="w-4 h-4 text-orange-500" />
                  <span>Гарантія збереження товару при транспортуванні</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <CreditCard className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg mb-2">Оплата після огляду</h2>
                <p className="text-gray-400 text-sm leading-relaxed">
                  Ми працюємо за принципом «оплата після огляду». Ви можете перевірити товар при отриманні 
                  у відділенні Нової Пошти — переконатися в цілісності, комплектності та якості виробів. 
                  Оплата проводиться лише після вашого особистого огляду. Такий підхід гарантує ваш 
                  спокій та довіру до кожної покупки.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
