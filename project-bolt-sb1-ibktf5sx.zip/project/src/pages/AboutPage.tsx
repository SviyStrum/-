import { Award, Users, Wrench, Target, MapPin } from 'lucide-react';
import { STORE_ADDRESS } from '../data/constants';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold text-white mb-2">Про нас</h1>
        <p className="text-gray-400 text-sm mb-10">Ваш надійний партнер у світі преміальних автомобільних дисків та шин</p>

        <div className="space-y-8">
          <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
            <p className="text-gray-300 text-sm leading-relaxed mb-6">
              Krutikolesa — це експертний каталог преміальних дисків та шин для власників престижних автомобілів.
              Ми спеціалізуємося на підборі оригінальних та післяпродажних виробів для автомобілів
              преміум і люкс сегментів: BMW, Mercedes-Benz, Audi, Porsche, Lexus, Volvo та інших.
            </p>
            <p className="text-gray-300 text-sm leading-relaxed mb-6">
              Наша команда має багаторічний досвід у сфері автомобільних комплектуючих. Ми розуміємо,
              наскільки важливо для власника преміум автомобіля мати ідеально підібрані диски та шини,
              які відповідають не лише технічним вимогам виробника, але й підкреслюють стиль і характер вашого авто.
            </p>
            <p className="text-gray-300 text-sm leading-relaxed mb-6">
              Ми співпрацюємо лише з перевіреними постачальниками та пропонуємо продукцію світових брендів:
              BBS, OZ Racing, Vossen, HRE, Michelin, Bridgestone, Continental, Pirelli та багатьох інших.
              Кожен товар проходить перевірку на оригінальність та відповідність заявленим параметрам.
            </p>
            <div className="flex items-start gap-3 pt-4 border-t border-white/10">
              <MapPin className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-white text-sm font-medium mb-1">Наша адреса</p>
                <p className="text-gray-400 text-sm">{STORE_ADDRESS}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
              <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-white font-semibold mb-2">Оригінальні вироби</h3>
              <p className="text-gray-400 text-sm leading-relaxed">Лише оригінальна продукція від світових виробників преміум сегменту</p>
            </div>
            <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
              <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-white font-semibold mb-2">Персональний підхід</h3>
              <p className="text-gray-400 text-sm leading-relaxed">Індивідуальна консультація для кожного клієнта з урахуванням усіх нюансів</p>
            </div>
            <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
              <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center mb-4">
                <Wrench className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-white font-semibold mb-2">Експертність у фітменті</h3>
              <p className="text-gray-400 text-sm leading-relaxed">Глибоке розуміння параметрів ET, вильоту, розболтовки та сумісності</p>
            </div>
            <div className="bg-neutral-900 border border-white/10 rounded-xl p-6">
              <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center mb-4">
                <Target className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-white font-semibold mb-2">Повна прозорість</h3>
              <p className="text-gray-400 text-sm leading-relaxed">Чесні умови, без прихованих комісій, оплата після огляду товару</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
