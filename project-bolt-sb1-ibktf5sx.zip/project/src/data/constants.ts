export const CAR_BRANDS = [
  'BMW', 'Audi', 'Mercedes-Benz', 'Volkswagen', 'Toyota', 'Skoda', 'Ford',
  'Renault', 'Opel', 'Nissan', 'Mazda', 'Honda', 'Hyundai', 'Kia', 'Peugeot',
  'Citroen', 'Volvo', 'Porsche', 'Lexus', 'Subaru', 'Mitsubishi', 'Chevrolet',
  'Jeep', 'Land Rover', 'Smart', 'Maybach', 'Alpina', 'Infiniti', 'Acura',
  'Suzuki', 'Daihatsu', 'Isuzu', 'Genesis', 'KG Mobility', 'SsangYong',
  'DS Automobiles', 'Bugatti', 'Alpine', 'Tesla', 'Cadillac', 'Buick', 'GMC',
  'Chrysler', 'Dodge', 'Ram', 'Lincoln', 'Rivian', 'Lucid', 'Jaguar', 'MINI',
  'Bentley', 'Rolls-Royce', 'Aston Martin', 'McLaren', 'Lotus', 'Caterham',
  'Fiat', 'Alfa Romeo', 'Maserati', 'Ferrari', 'Lamborghini', 'Lancia', 'Abarth',
  'Pagani', 'Geely', 'BYD', 'Chery', 'Haval', 'GWM', 'Changan', 'Li Auto', 'NIO',
  'XPeng', 'Zeekr', 'Lynk & Co', 'Tank', 'Exeed', 'Omoda', 'Hongqi', 'GAC', 'FAW',
  'Dongfeng', 'Xiaomi', 'Seat', 'Cupra', 'Dacia', 'Polestar', 'Koenigsegg', 'Інша марка'
];

export const WHEEL_TYPES = ['Литі', 'Штамповані', 'Ковані', 'Flow Forming'];

export const WHEEL_DIAMETERS = ['R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23'];

export const WHEEL_BRANDS = ['BBS', 'OEM', 'OZ Racing', 'Vossen', 'HRE', 'Forgiato', 'Rotiform', 'Enkei', 'RAYS', 'ADV.1'];

export const TIRE_BRANDS = [
  'Michelin', 'Bridgestone', 'Continental', 'Goodyear', 'Pirelli', 'Hankook',
  'Nokian Tyres', 'Yokohama', 'Toyo', 'Kumho', 'Dunlop', 'BFGoodrich',
  'Nexen', 'Barum', 'Fulda', 'Sava', 'Uniroyal', 'Firestone', 'Starmaxx',
  'General Tire', 'Laufenn', 'Roadstone', 'Falken', 'Kapsen', 'Sailun',
  'Triangle', 'Goodride'
];

export const TESTIMONIALS = [
  { name: 'Олександр К.', car: 'Porsche Cayenne', rating: 5, text: 'Замовляв диски R21 для Cayenne Turbo. Менеджер підібрав ідеальний варіант під мій автомобіль. Професійний підхід, швидка відповідь у Telegram. Рекомендую!' },
  { name: 'Марія П.', car: 'BMW M5 Competition', rating: 5, text: 'Неймовірний сервіс! Підібрали шини Michelin Pilot Sport 4S для M5. Доставка Новою Поштою прийшла за 2 дні. Класна упаковка, все ідеально. Обов\'язково повернусь.' },
  { name: 'Андрій В.', car: 'Audi RS6 Avant', rating: 5, text: 'Шукав ковані диски для RS6. Ребята запропонували відмінний варіант від Vossen. Якість на висоті, ціна адекватна. Дякую за консультацію щодо параметрів ET та вильоту.' },
  { name: 'Ірина С.', car: 'Volkswagen Touareg', rating: 5, text: 'Вперше замовляла диски через месенджер. Все прозоро, без підводних каменів. Менеджер показав фото, пояснив сумісність. Дуже задоволена результатом.' },
  { name: 'Віталій М.', car: 'Mercedes-AMG G63', rating: 5, text: 'Підбирали диски R22 для G-Wagon. Не прості параметри, але команда впоралась на відмінно. Дуже вдячний за терпіння та увагу до деталей. Рекомендую всім власникам преміум авто.' },
  { name: 'Наталія Г.', car: 'Lexus LX 570', rating: 5, text: 'Замовляла шини Bridgestone для LX 570. Все прийшло вчасно, перевірила при отриманні — комплект повний, без зауважень. Прекрасний сервіс, зручна оплата після огляду.' },
  { name: 'Дмитро Р.', car: 'BMW X7', rating: 5, text: 'Підібрали шини Continental ContiSportContact для X7. Менеджер знає свою справу, детально розповів про всі характеристики. Тепер мій BMW їде як по рейках. Вдячний!' },
  { name: 'Світлана Б.', car: 'Audi Q8', rating: 5, text: 'Дуже професійний підхід. Замовляла диски для Q8 — відповіли швидко, уточнили всі параметри, доставили швидко. Менеджер знаннями вразив. Це найкращий магазин автошин та дисків.' },
  { name: 'Роман Л.', car: 'Porsche Macan S', rating: 5, text: 'Шукав шини для Macan S. Рекомендували Pirelli P Zero — чудовий вибір. Машина стала впевненішою на трасі. Обслуговування на найвищому рівні. Дякую команді!' },
  { name: 'Юлія Д.', car: 'Mercedes E-Class', rating: 5, text: 'Замовляла зимову гуму Nokian Tyres для E-Class. Консультація дуже допомогла вибрати правильний індекс швидкості. Все підійшло ідеально. Тепер тільки до вас!' },
  { name: 'Євген Ш.', car: 'BMW 3 Series G20', rating: 5, text: 'Підбирали диски OE для BMW G20. Менеджер знав усі коди оригінальних дисків. Підібрали оригінал, перевірили артикули. Відмінна робота, ціную вашу експертність.' },
  { name: 'Тетяна З.', car: 'Volvo XC90', rating: 5, text: 'Замовляла шини Goodyear для XC90. Все як у домовленості — відповіли за 5 хвилин, перевірили сумісність, швидко відправили. Відмінний сервіс для власників преміум авто.' },
  { name: 'Максим Ф.', car: 'Audi A8', rating: 5, text: 'Високий рівень обслуговування. Підібрали шини для A8 Long, врахували всі нюанси. Оплата після огляду — дуже зручно. Великий асортимент, швидкі відповіді. Топ!' },
  { name: 'Катерина О.', car: 'BMW X5', rating: 4, text: 'Підбір дисків пройшов відмінно, менеджер дуже компетентний. Єдиний нюанс — доставка затрималась на день через сезонний пік перед зимою. Та все одно задоволена сервісом.' },
  { name: 'Богдан Н.', car: 'Mercedes GLE Coupe', rating: 4, text: 'Якісний сервіс та консультація. Доставка зайняла трохи більше часу через погодні умови на трасі. Але диски приїхали в ідеальній упаковці, без жодних пошкоджень. Рекомендую!' },
];

export const TELEGRAM_URL = 'https://t.me/share/url?url=&text=';
export const WHATSAPP_URL = 'https://wa.me/?text=';

export const STORE_ADDRESS = 'вулиця Івана Франка, 149, Виноградів, Закарпатська область, Україна, 90300';
