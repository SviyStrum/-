import { CircleDot, MessageCircle } from 'lucide-react';
import { STORE_ADDRESS } from '../data/constants';

interface FooterProps {
  setCurrentPage: (page: string) => void;
}

export default function Footer({ setCurrentPage }: FooterProps) {
  return (
    <footer className="bg-black border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <button
              onClick={() => setCurrentPage('home')}
              className="flex items-center gap-2 text-orange-500 mb-4"
            >
              <CircleDot className="w-6 h-6" />
              <span className="text-white font-bold text-lg tracking-wider">Kruti<span className="text-orange-500">kolesa</span></span>
            </button>
            <p className="text-gray-400 text-sm leading-relaxed">
              Каталог дисків та шин для власників автомобілів по всій Україні.
            </p>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Навігація</h4>
            <div className="space-y-2">
              {[
                { label: 'Головна', page: 'home' },
                { label: 'Диски', page: 'wheels' },
                { label: 'Шини', page: 'tires' },
                { label: 'Доставка', page: 'delivery' },
                { label: 'Про нас', page: 'about' },
                { label: 'Контакти', page: 'contacts' },
              ].map((item) => (
                <button
                  key={item.page}
                  onClick={() => setCurrentPage(item.page)}
                  className="block text-gray-400 hover:text-orange-500 text-sm transition-colors"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Зв'язатися</h4>
            <div className="space-y-3">
              <a
                href="https://t.me/share/url?url=&text=Добрий день. Мене цікавить підбір дисків/шин. Прошу уточнити деталі."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-blue-400 hover:text-blue-300 text-sm transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                Telegram
              </a>
              <a
                href="https://wa.me/?text=Добрий день. Мене цікавить підбір дисків/шин. Прошу уточнити деталі."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-green-400 hover:text-green-300 text-sm transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 text-center text-gray-500 text-xs">
          {STORE_ADDRESS}
        </div>
        <div className="border-t border-white/10 mt-6 pt-6 text-center text-gray-500 text-sm">
          © 2024 Krutikolesa. Каталог дисків та шин. Усі права захищені.
        </div>
      </div>
    </footer>
  );
}
