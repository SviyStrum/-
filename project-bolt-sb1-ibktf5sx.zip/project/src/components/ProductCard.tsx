import { MessageCircle } from 'lucide-react';

interface ProductCardProps {
  image: string;
  code: number;
  onContact: (code: number) => void;
}

export default function ProductCard({ image, code, onContact }: ProductCardProps) {
  return (
    <div className="bg-neutral-900 border border-white/10 rounded-xl overflow-hidden hover:border-orange-500/50 transition-colors group">
      <div className="aspect-square bg-neutral-800 overflow-hidden">
        <img
          src={image}
          alt={`Код товару ${code}`}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
      </div>
      <div className="p-4">
        <p className="text-orange-500 font-mono text-sm mb-2">Код товару: {code}</p>
        <p className="text-gray-400 text-xs leading-relaxed mb-4">
          Лінія розмірів. Уточнюйте у менеджера деталі та сумісність з вашим авто.
        </p>
        <button
          onClick={() => onContact(code)}
          className="w-full flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium py-2.5 rounded-lg transition-colors"
        >
          <MessageCircle className="w-4 h-4" />
          Уточнити наявність
        </button>
      </div>
    </div>
  );
}
