import { X, MessageCircle } from 'lucide-react';

interface ContactModalProps {
  productCode?: string;
  customMessage?: string;
  onClose: () => void;
}

export default function ContactModal({ productCode, customMessage, onClose }: ContactModalProps) {
  const message = customMessage
    ? customMessage
    : productCode
      ? `Добрий день. Мене цікавить Код товару ${productCode}. Прошу уточнити наявність та деталі.`
      : `Добрий день. Мене цікавить підбір дисків/шин для мого автомобіля. Прошу уточнити деталі.`;

  const tgUrl = `https://t.me/share/url?url=&text=${encodeURIComponent(message)}`;
  const waUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-neutral-900 border border-white/10 rounded-xl p-6 max-w-md w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-white text-lg font-semibold">
            {productCode ? 'Уточнити наявність' : 'Зв\'язатися з менеджером'}
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <p className="text-gray-400 text-sm mb-6">Оберіть зручний месенджер для зв'язку з менеджером:</p>
        <div className="space-y-3">
          <a
            href={tgUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 w-full bg-blue-600 hover:bg-blue-500 text-white px-5 py-3 rounded-lg font-medium transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            Написати у Telegram
          </a>
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 w-full bg-green-600 hover:bg-green-500 text-white px-5 py-3 rounded-lg font-medium transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            Написати у WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}
