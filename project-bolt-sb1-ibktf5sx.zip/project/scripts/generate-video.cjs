const { createCanvas } = require('canvas');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegStatic = require('ffmpeg-static');

ffmpeg.setFfmpegPath(ffmpegStatic);

const OUTPUT_DIR = path.join(__dirname, '../tmp-frames');
const PUBLIC_DIR = path.join(__dirname, '../public');

async function generateVideo() {
  if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  const width = 1920;
  const height = 1080;
  const duration = 10;
  const fps = 24;
  const totalFrames = duration * fps;

  for (let frame = 0; frame < totalFrames; frame++) {
    const t = frame / totalFrames;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#1a1a1a');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#1a1a1a';
    ctx.lineWidth = 1;
    for (let i = 0; i < width; i += 40) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, height); ctx.stroke(); }
    for (let i = 0; i < height; i += 40) { ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(width, i); ctx.stroke(); }

    ctx.strokeStyle = '#2a2a2a';
    ctx.lineWidth = 3;
    const wheels = [
      { x: 200, y: 300, r: 80, speed: 1 },
      { x: 600, y: 500, r: 60, speed: -1.5 },
      { x: 900, y: 200, r: 70, speed: 0.8 },
      { x: 1400, y: 400, r: 90, speed: -1.2 },
      { x: 1800, y: 600, r: 65, speed: 1.5 },
    ];
    for (const w of wheels) {
      const rot = t * Math.PI * 2 * w.speed;
      ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, Math.PI * 2); ctx.stroke();
      for (let i = 0; i < 5; i++) {
        const angle = rot + (Math.PI * 2 / 5) * i;
        ctx.beginPath(); ctx.moveTo(w.x, w.y); ctx.lineTo(w.x + Math.cos(angle) * w.r, w.y + Math.sin(angle) * w.r); ctx.stroke();
      }
    }

    ctx.strokeStyle = '#FF6B00';
    ctx.lineWidth = 1;
    ctx.globalAlpha = 0.3;
    for (let i = 0; i < 15; i++) {
      const offset = (frame * 2 + i * 100) % (width + 200);
      const y = (i * 67) % height;
      const len = 50 + Math.sin(i) * 50;
      ctx.beginPath(); ctx.moveTo(offset - 200, y); ctx.lineTo(offset + len - 200, y); ctx.stroke();
    }
    ctx.globalAlpha = 1.0;

    const buf = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(OUTPUT_DIR, `frame-${String(frame).padStart(4, '0')}.png`), buf);
  }

  await new Promise((resolve, reject) => {
    ffmpeg()
      .input(path.join(OUTPUT_DIR, 'frame-%04d.png'))
      .inputFPS(fps)
      .videoCodec('libx264')
      .size(`${width}x${height}`)
      .output(path.join(PUBLIC_DIR, 'hero-bg.mp4'))
      .on('end', () => {
        console.log('Video generated successfully');
        fs.rmSync(OUTPUT_DIR, { recursive: true, force: true });
        resolve(null);
      })
      .on('error', (err) => {
        console.error('FFmpeg error:', err);
        reject(err);
      })
      .run();
  });
}

generateVideo().catch(console.error);
