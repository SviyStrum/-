const { createCanvas } = require('canvas');
const fs = require('fs');
const path = require('path');

const WHEEL_DIR = path.join(__dirname, '../public/wheel-cards');
const TIRE_DIR = path.join(__dirname, '../public/tire-cards');
const HERO_DIR = path.join(__dirname, '../public');

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function drawWheel(canvas, ctx, id) {
  const w = canvas.width, h = canvas.height;
  // Dark background
  const gradient = ctx.createLinearGradient(0, 0, w, h);
  gradient.addColorStop(0, '#1a1a1a');
  gradient.addColorStop(1, '#0d0d0d');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);

  // Subtle grid pattern
  ctx.strokeStyle = '#2a2a2a';
  ctx.lineWidth = 1;
  for (let i = 0; i < w; i += 40) {
    ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, h); ctx.stroke();
  }
  for (let i = 0; i < h; i += 40) {
    ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(w, i); ctx.stroke();
  }

  // Center wheel
  const cx = w / 2, cy = h / 2, r = 110;
  const spokeCount = 5 + (id % 3);
  const rimColor = id % 2 === 0 ? '#2a2a2a' : '#1f1f1f';
  const accentColor = '#FF6B00';

  // Outer rim
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = '#333';
  ctx.fill();
  ctx.strokeStyle = '#555';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Inner rim
  ctx.beginPath();
  ctx.arc(cx, cy, r - 8, 0, Math.PI * 2);
  ctx.fillStyle = '#222';
  ctx.fill();
  ctx.strokeStyle = '#444';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Spokes
  for (let i = 0; i < spokeCount; i++) {
    const angle = (Math.PI * 2 / spokeCount) * i - Math.PI / 2;
    const innerR = 25;
    const outerR = r - 12;
    const sx = cx + Math.cos(angle) * innerR;
    const sy = cy + Math.sin(angle) * innerR;
    const ex = cx + Math.cos(angle) * outerR;
    const ey = cy + Math.sin(angle) * outerR;

    // Draw spoke
    const spokeWidth = 12 + (id % 4) * 3;
    const perpAngle = angle + Math.PI / 2;
    const pw = spokeWidth / 2;

    ctx.beginPath();
    ctx.moveTo(sx + Math.cos(perpAngle) * pw, sy + Math.sin(perpAngle) * pw);
    ctx.lineTo(ex + Math.cos(perpAngle) * pw, ey + Math.sin(perpAngle) * pw);
    ctx.lineTo(ex - Math.cos(perpAngle) * pw, ey - Math.sin(perpAngle) * pw);
    ctx.lineTo(sx - Math.cos(perpAngle) * pw, sy - Math.sin(perpAngle) * pw);
    ctx.closePath();
    ctx.fillStyle = rimColor;
    ctx.fill();
    ctx.strokeStyle = '#555';
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  // Center cap
  ctx.beginPath();
  ctx.arc(cx, cy, 22, 0, Math.PI * 2);
  ctx.fillStyle = '#111';
  ctx.fill();
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 2;
  ctx.stroke();

  // Brand logo text
  ctx.font = 'bold 10px Arial';
  ctx.fillStyle = accentColor;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('RACING', cx, cy);

  // Lug nuts
  for (let i = 0; i < 5; i++) {
    const angle = (Math.PI * 2 / 5) * i;
    const lx = cx + Math.cos(angle) * 14;
    const ly = cy + Math.sin(angle) * 14;
    ctx.beginPath();
    ctx.arc(lx, ly, 3, 0, Math.PI * 2);
    ctx.fillStyle = '#777';
    ctx.fill();
  }

  // Specs text
  ctx.font = '13px Arial';
  ctx.fillStyle = '#888';
  ctx.textAlign = 'center';
  ctx.fillText(`Код: ${512 + id}`, w / 2, h - 22);
}

function drawTire(canvas, ctx, id) {
  const w = canvas.width, h = canvas.height;
  // Dark background
  const gradient = ctx.createLinearGradient(0, 0, w, h);
  gradient.addColorStop(0, '#1a1a1a');
  gradient.addColorStop(1, '#0d0d0d');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);

  // Subtle grid pattern
  ctx.strokeStyle = '#2a2a2a';
  ctx.lineWidth = 1;
  for (let i = 0; i < w; i += 40) {
    ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, h); ctx.stroke();
  }
  for (let i = 0; i < h; i += 40) {
    ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(w, i); ctx.stroke();
  }

  const cx = w / 2, cy = h / 2, rw = 120, rh = 100;
  const accentColor = '#FF6B00';

  // Tire body
  ctx.beginPath();
  ctx.ellipse(cx, cy, rw, rh, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#222';
  ctx.fill();
  ctx.strokeStyle = '#444';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Outer tire ring
  ctx.beginPath();
  ctx.ellipse(cx, cy, rw - 8, rh - 8, 0, 0, Math.PI * 2);
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 8;
  ctx.stroke();

  // Tread pattern
  ctx.save();
  ctx.beginPath();
  ctx.ellipse(cx, cy, rw - 16, rh - 16, 0, 0, Math.PI * 2);
  ctx.clip();
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 4;
  for (let y = cy - rh; y < cy + rh; y += 8) {
    ctx.beginPath();
    ctx.moveTo(cx - rw, y);
    ctx.lineTo(cx + rw, y + (id % 2 === 0 ? 6 : -6));
    ctx.stroke();
  }
  ctx.restore();

  // Sidewall text
  const brandNames = ['MICHELIN', 'BRIDGESTONE', 'CONTINENTAL', 'GOODYEAR', 'PIRELLI', 'HANKOOK', 'NOKIAN', 'YOKOHAMA', 'TOYO', 'KUMHO', 'DUNLOP', 'BF GOODRICH', 'NEXEN', 'BARUM', 'FULDA', 'SAVA', 'UNIROYAL', 'FIRESTONE', 'STARMAXX', 'GENERAL', 'LAUFENN', 'ROADSTONE', 'FALKEN', 'KAPSEN', 'SAILUN', 'TRIANGLE', 'GOODRIDE'];
  const brand = brandNames[id % brandNames.length];
  ctx.font = 'bold 11px Arial';
  ctx.fillStyle = '#888';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(brand, cx, cy - rh - 12);

  // Size text
  ctx.font = 'bold 12px Arial';
  ctx.fillStyle = accentColor;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const sizes = ['225/45 R17', '245/40 R18', '255/35 R19', '235/50 R18', '265/30 R20', '215/55 R17', '275/35 R19', '245/35 R20', '225/50 R18', '255/45 R19'];
  ctx.fillText(sizes[id % sizes.length], cx, cy + rh + 16);

  // Code text
  ctx.font = '12px Arial';
  ctx.fillStyle = '#888';
  ctx.fillText(`Код: ${815 + id}`, cx, h - 16);
}

function drawHero(canvas, ctx) {
  const w = canvas.width, h = canvas.height;
  const gradient = ctx.createLinearGradient(0, 0, w, h);
  gradient.addColorStop(0, '#0a0a0a');
  gradient.addColorStop(1, '#1a1a1a');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);

  // Draw abstract motion lines
  ctx.strokeStyle = '#FF6B00';
  ctx.lineWidth = 1;
  for (let i = 0; i < 20; i++) {
    const y = Math.random() * h;
    const len = 50 + Math.random() * 150;
    const x = Math.random() * w;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + len, y);
    ctx.stroke();
  }

  // Draw some wheel silhouettes
  ctx.strokeStyle = '#2a2a2a';
  ctx.lineWidth = 3;
  const wheels = [[200, 300], [600, 500], [900, 200], [1400, 400], [1800, 600]];
  for (const [wx, wy] of wheels) {
    ctx.beginPath();
    ctx.arc(wx, wy, 80, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 5; i++) {
      const angle = (Math.PI * 2 / 5) * i;
      ctx.beginPath();
      ctx.moveTo(wx, wy);
      ctx.lineTo(wx + Math.cos(angle) * 80, wy + Math.sin(angle) * 80);
      ctx.stroke();
    }
  }
}

function generate() {
  ensureDir(WHEEL_DIR);
  ensureDir(TIRE_DIR);
  ensureDir(HERO_DIR);

  // Generate 10 wheel cards
  for (let i = 0; i < 10; i++) {
    const canvas = createCanvas(500, 400);
    const ctx = canvas.getContext('2d');
    drawWheel(canvas, ctx, i);
    const buf = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(WHEEL_DIR, `wheel-${i + 1}.png`), buf);
  }

  // Generate 10 tire cards
  for (let i = 0; i < 10; i++) {
    const canvas = createCanvas(500, 400);
    const ctx = canvas.getContext('2d');
    drawTire(canvas, ctx, i);
    const buf = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(TIRE_DIR, `tire-${i + 1}.png`), buf);
  }

  // Generate hero poster image
  const heroCanvas = createCanvas(1920, 1080);
  const heroCtx = heroCanvas.getContext('2d');
  drawHero(heroCanvas, heroCtx);
  const heroBuf = heroCanvas.toBuffer('image/png');
  fs.writeFileSync(path.join(HERO_DIR, 'hero-poster.png'), heroBuf);

  console.log('Generated images successfully');
}

generate();
